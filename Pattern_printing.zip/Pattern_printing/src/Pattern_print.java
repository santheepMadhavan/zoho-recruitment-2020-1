import java.util.*;

public class Pattern_print {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int N = input.nextInt(), i, j, M; 
	    System.out.println("Input: " + N); 
	  
	    for (i = 1; i <= N; i++)  
	    { 
	        for (j = 1; j <= N; j++)  
	        { 
	            M = i < j ? i : j; 
	            System.out.print(N - M + 1); 
	        } 
	        System.out.println(); 
	    } 
	}

}
